let age = 26;
console.log(age);
let year = 1995;
console.log(year);
let imya = "lola";
console.log(imya);
