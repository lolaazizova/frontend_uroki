let user = {
    name: "John",
    
    surname: "Smith",
    age: 30,
    place : "London",
};
  for (let key in user) {
      console.log(user[key]);
      
  }
let telephone = ["iphone", "samsung","xiaomi"];
for (let phone in telephone){
    console.log (telephone[phone]);
}